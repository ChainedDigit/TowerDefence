package com.example.timer_test;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Timer;
import java.util.TimerTask;
import java.lang.Math;

public class MainActivity extends AppCompatActivity {

    public TextView textBox;
    public TextView arrowBox;
    public View lazer;
    public TextView distanceBox;
    public double timeGone;
    public Timer myTimer;
    public ViewGroup.LayoutParams lazerParams;

    public String distanceText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textBox = findViewById(R.id.textBox);
        arrowBox = findViewById(R.id.arrowBox);
        lazer = findViewById(R.id.laser);
        distanceBox = findViewById(R.id.distanceBox);
        distanceText = getResources().getString(R.string.distanceText);
        timeGone = 0;

        lazerParams = lazer.getLayoutParams();
        lazer.setLayoutParams(lazerParams);

        distanceBox.setText(distanceText);

        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                moveText();
                moveArrow();
                moveLazer(distanceBox);

                timeGone+=0.05;
                if(timeGone>10) timeGone=0;
            }
        };

        myTimer = new Timer();
        myTimer.scheduleAtFixedRate(timerTask, 10, 20);
    }

    private void moveText(){
        textBox.setTranslationX( (float)Math.sin(timeGone) * 300 );
        textBox.setTranslationY( (float)Math.cos(timeGone) * 400 );
    }
    private void moveArrow(){
        arrowBox.setRotation( (float)Math.toDegrees(Math.atan2(
                (textBox.getTranslationY()-arrowBox.getTranslationY()) ,
                (textBox.getTranslationX()-arrowBox.getTranslationX())
                )
        ));
    }
    private void moveLazer(TextView distanceBox){

        // set the rotation of the lazer
        lazer.setRotation( (float)Math.toDegrees(Math.atan2(
                (textBox.getTranslationY()-arrowBox.getTranslationY()) ,
                (textBox.getTranslationX()-arrowBox.getTranslationX())
                )
        ));

        // set the position of the lazer
        lazer.setTranslationX( (textBox.getTranslationX()+arrowBox.getTranslationX())/2 );
        lazer.setTranslationY( (textBox.getTranslationY()+arrowBox.getTranslationY())/2 );

        // set the lenth of the lazer
        runOnUiThread(new Runnable() {

            @Override
            public void run() {
                int deltaX = Math.abs((int)(textBox.getTranslationX()-arrowBox.getTranslationX()));
                int deltaY = Math.abs((int)(textBox.getTranslationY()-arrowBox.getTranslationY()));
                int distance = (int) Math.sqrt(Math.pow(deltaX,2)+Math.pow(deltaY,2));
                distanceBox.setText(String.valueOf(distance));
                lazerParams.width = distance;

            }
        });


    }

}